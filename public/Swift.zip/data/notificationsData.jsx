
// import { v4 as uuidv4 } from "uuid";

// export const notifications = [
//   {
//     id: uuidv4(),
    
//     name: "Brain Cumin",
//     title: "commented on your post",
//     des: "Maecenas quam nunc, sagittis non condimentum at, rutrum sit amet eros. Fusce rutrum, lectus in blandit sagittis, mi tortor ullamcorper mi, vitae vestibulum libero quam a nisi. In eu mauris et neque sodales porta eu eget dui",
//     time: "3 Days Ago",
//   },
//   {
//     id: uuidv4(),
  
//     name: "Marianne Floyd",
//     title: "commented on your post",
//     des: "Maecenas quam nunc, sagittis non condimentum at, rutrum sit amet eros. Fusce rutrum, lectus in blandit sagittis, mi tortor ullamcorper mi, vitae vestibulum libero quam a nisi. In eu mauris et neque sodales porta eu eget dui",
//     time: "8 Days Ago",
//   },
//   {
//     id: uuidv4(),
   
//     name: "Valerie Nelson",
//     title: "commented on your post",
//     des: "Maecenas quam nunc, sagittis non condimentum at, rutrum sit amet eros. Fusce rutrum, lectus in blandit sagittis, mi tortor ullamcorper mi, vitae vestibulum libero quam a nisi. In eu mauris et neque sodales porta eu eget dui",
//     time: "7 Days Ago",
//   },
//   {
//     id: uuidv4(),

//     name: "Ben Castro",
//     title: "commented on your post",
//     des: "Maecenas quam nunc, sagittis non condimentum at, rutrum sit amet eros. Fusce rutrum, lectus in blandit sagittis, mi tortor ullamcorper mi, vitae vestibulum libero quam a nisi. In eu mauris et neque sodales porta eu eget dui",
//     time: "8 Days Ago",
//   },
//   {
//     id: uuidv4(),
  
//     name: "Nadia Henry",
//     title: "commented on your post",
//     des: "Maecenas quam nunc, sagittis non condimentum at, rutrum sit amet eros. Fusce rutrum, lectus in blandit sagittis, mi tortor ullamcorper mi, vitae vestibulum libero quam a nisi. In eu mauris et neque sodales porta eu eget dui",
//     time: "1 Days Ago",
//   },
//   {
//     id: uuidv4(),
    
//     name: "Gayle Homes",
//     title: "commented on your post",
//     des: "Maecenas quam nunc, sagittis non condimentum at, rutrum sit amet eros. Fusce rutrum, lectus in blandit sagittis, mi tortor ullamcorper mi, vitae vestibulum libero quam a nisi. In eu mauris et neque sodales porta eu eget dui",
//     time: "2 Days Ago",
//   },
//   {
//     id: uuidv4(),
  
//     name: "Sylvia Hoffman",
//     title: "commented on your post",
//     des: "Maecenas quam nunc, sagittis non condimentum at, rutrum sit amet eros. Fusce rutrum, lectus in blandit sagittis, mi tortor ullamcorper mi, vitae vestibulum libero quam a nisi. In eu mauris et neque sodales porta eu eget dui",
//     time: "5 Days Ago",
//   },
//   {
//     id: uuidv4(),

//     name: "Camille Sullivan",
//     title: "commented on your post",
//     des: "Maecenas quam nunc, sagittis non condimentum at, rutrum sit amet eros. Fusce rutrum, lectus in blandit sagittis, mi tortor ullamcorper mi, vitae vestibulum libero quam a nisi. In eu mauris et neque sodales porta eu eget dui",
//     time: "6 Days Ago",
//   },
// ];
